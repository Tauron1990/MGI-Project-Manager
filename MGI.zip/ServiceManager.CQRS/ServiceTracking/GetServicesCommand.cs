﻿using JetBrains.Annotations;
using Tauron.CQRS.Services;

namespace ServiceManager.CQRS.ServiceTracking
{
    [PublicAPI]
    public class GetServicesCommand : IAmbientCommand
    {
        
    }
}