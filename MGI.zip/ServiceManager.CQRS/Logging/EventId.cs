﻿namespace ServiceManager.CQRS.Logging
{
    public class SaveableEventId
    {
        public string Name { get; set; }

        public int Id { get; set; }
    }
}