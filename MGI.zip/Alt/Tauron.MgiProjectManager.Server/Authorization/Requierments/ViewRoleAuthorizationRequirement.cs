﻿using Microsoft.AspNetCore.Authorization;

namespace Tauron.MgiProjectManager.Server.Authorization
{
    public class ViewRoleAuthorizationRequirement : IAuthorizationRequirement
    {

    }
}