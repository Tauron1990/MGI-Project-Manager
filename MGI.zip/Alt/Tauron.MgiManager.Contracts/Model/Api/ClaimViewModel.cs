﻿namespace Tauron.MgiProjectManager.Model.Api
{
    public class ClaimViewModel
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}