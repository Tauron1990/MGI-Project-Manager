﻿namespace Tauron.MgiProjectManager.Model.Api
{
    public class UnAssociateFile
    {
        public string OperationId { get; set; }

        public string FileName { get; set; }
    }
}