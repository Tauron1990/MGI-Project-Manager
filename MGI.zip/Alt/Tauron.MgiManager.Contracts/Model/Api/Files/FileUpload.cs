﻿namespace Tauron.MgiProjectManager.Model.Api
{
    public class FileUpload
    {
        public string Message { get; set; }

        public string OperationId { get; set; }
    }
}