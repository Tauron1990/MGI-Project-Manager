﻿namespace Tauron.MgiProjectManager.Model.Api
{
    public class AssociateFile
    {
        public string OperationId { get; set; }

        public string JobNumber { get; set; }
    }
}