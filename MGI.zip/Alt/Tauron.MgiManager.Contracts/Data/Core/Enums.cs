﻿// =============================
// Email: info@ebenmonney.com
// www.ebenmonney.com/templates
// =============================

namespace Tauron.MgiProjectManager.Data.Core
{
    public enum Gender
    {
        None,
        Female,
        Male
    }
}
