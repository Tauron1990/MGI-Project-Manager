﻿namespace Tauron.MgiProjectManager
{
    public class FilesConfig
    {
        public string NameExpression { get; set; }

        public string CaseRange { get; set; }

        public int MaxDbSize { get; set; }
    }
}