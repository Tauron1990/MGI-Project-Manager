﻿namespace Tauron.MgiProjectManager.Dispatcher
{
    public static class OperationNames
    {
        public const string FileOperationType = "FileOperation";

        public const string MultiFileOperation = "MultiFile";
        public const string LinkingFileOperation = "LinkingFile";
    }
}