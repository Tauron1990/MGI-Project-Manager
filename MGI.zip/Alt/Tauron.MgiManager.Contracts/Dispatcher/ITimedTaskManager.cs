﻿namespace Tauron.MgiProjectManager.Dispatcher
{
    public interface ITimedTaskManager
    {
        void Start();
    }
}