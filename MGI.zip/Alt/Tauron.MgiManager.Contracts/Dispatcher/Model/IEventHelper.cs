﻿namespace Tauron.MgiProjectManager.Dispatcher.Model
{
    public interface IEventHelper
    {
        EventToken GetEventToken();
    }
}