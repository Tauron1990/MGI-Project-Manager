﻿namespace Tauron.MgiProjectManager
{
    public class AppSettings
    {
        public SmtpConfig SmtpConfig { get; set; }

        public FilesConfig FilesConfig { get; set; }

        public LoggingConfig Logging { get; set; }

    }
}