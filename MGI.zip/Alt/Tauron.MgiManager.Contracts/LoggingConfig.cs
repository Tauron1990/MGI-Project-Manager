﻿namespace Tauron.MgiProjectManager
{
    public class LoggingConfig
    {
        public int BatchEntries { get; set; }
    }
}