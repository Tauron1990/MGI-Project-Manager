﻿namespace Tauron.MgiProjectManager
{
    public enum LiveCycle
    {
        Scoped,
        Transistent,
        Singleton
    }
}