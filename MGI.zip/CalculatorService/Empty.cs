﻿namespace CalculatorService
{
    public class Empty
    {
        
    }
}