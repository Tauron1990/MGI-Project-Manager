﻿namespace Tauron.CQRS.Common.Dto
{
    public class ApiObjectId
    {
        public string ApiKey { get; set; }

        public string Id { get; set; }
    }
}