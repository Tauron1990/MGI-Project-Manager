﻿using System;

namespace Tauron.CQRS.Common.Dto.TypeHandling
{
    //public interface ITypeRegistry
    //{
    //    string GetName(Type type);

    //    bool Contains(Type type);

    //    void Register(string name, Type namedType);

    //    Type Resolve(string name);
    //}
}
