﻿namespace Tauron.CQRS.Common.Dto.Persistable
{
    public interface IObjectData : IJsonFormatable
    {
        
    }
}