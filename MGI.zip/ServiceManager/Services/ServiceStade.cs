﻿namespace ServiceManager.Services
{
    public enum ServiceStade
    {
        Error,
        Running,
        Ready
    }
}