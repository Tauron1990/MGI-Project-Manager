﻿using System;
using Microsoft.AspNetCore.Identity;

namespace MgiManager.Data
{
    public sealed class InternalRole : IdentityRole<Guid>
    {

    }
}