﻿using System;
using Microsoft.AspNetCore.Identity;

namespace MgiManager.Data
{
    public sealed class InternalUser : IdentityUser<Guid>
    {
        
    }
}