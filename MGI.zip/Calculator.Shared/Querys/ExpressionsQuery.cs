﻿using System.Collections.Generic;
using Calculator.Shared.Dto;
using CQRSlite.Queries;

namespace Calculator.Shared.Querys
{
    public sealed class ExpressionsQuery : IQuery<ExpressionResult>
    {
        
    }
}