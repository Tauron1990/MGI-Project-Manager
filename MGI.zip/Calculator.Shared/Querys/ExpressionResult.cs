﻿using System;
using System.Collections;
using System.Collections.Generic;
using Calculator.Shared.Dto;

namespace Calculator.Shared.Querys
{
    public class ExpressionResult
    {
        public ExpressionEntry[] Entrys { get; set; }
    }
}