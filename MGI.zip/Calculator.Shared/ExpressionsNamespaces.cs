﻿using System;

namespace Calculator.Shared
{
    public static class ExpressionsNamespaces
    {
        public static readonly Guid ExpressionAggregate = Guid.Parse("CEB65F7B-CD55-4EE3-ADE1-F419DFAFA225");
    }
}