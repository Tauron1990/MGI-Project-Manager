﻿using CQRSlite.Queries;

namespace EventDeliveryTest.Test
{
    public class TestQueryData : IQuery<TestData>
    {
        
    }
}