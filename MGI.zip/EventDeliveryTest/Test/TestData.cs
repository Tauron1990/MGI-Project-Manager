﻿namespace EventDeliveryTest.Test
{
    public class TestData
    {
        public string  Parameter { get;  }

        public TestData(string parameter) => Parameter = parameter;
    }
}