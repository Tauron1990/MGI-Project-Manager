﻿namespace EventDeliveryTest
{
    public class Empty
    {
        
    }
}