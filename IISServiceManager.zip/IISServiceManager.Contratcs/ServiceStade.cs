﻿namespace IISServiceManager.Contratcs
{
    public enum ServiceStade
    {
        Running,
        Stopped,
        NotInstalled
    }
}