﻿namespace IISServiceManager.Contratcs
{
    public enum ServiceType
    {
        Essential,
        Normal
    }
}